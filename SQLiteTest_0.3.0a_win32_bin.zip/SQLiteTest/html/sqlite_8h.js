var sqlite_8h =
[
    [ "DEFAULT_DBNAME", "sqlite_8h.html#acfcad24977a121f8cb40c7abc0861e13", null ],
    [ "DEFAULT_TABLENAME", "sqlite_8h.html#adda28390da72cdfef24377fcd0262e17", null ]
];