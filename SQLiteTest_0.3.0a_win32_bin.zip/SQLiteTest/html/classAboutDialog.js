var classAboutDialog =
[
    [ "AboutDialog", "classAboutDialog.html#ad96fc2ce8de7568ace543b7c69c71c56", null ],
    [ "~AboutDialog", "classAboutDialog.html#a3d87f5a26a175bb2573965c98af6d4ca", null ]
];