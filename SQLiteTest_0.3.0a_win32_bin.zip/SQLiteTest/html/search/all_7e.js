var searchData=
[
  ['_7eaboutdialog',['~AboutDialog',['../classAboutDialog.html#a3d87f5a26a175bb2573965c98af6d4ca',1,'AboutDialog']]],
  ['_7ehelpsetdialog',['~HelpSetDialog',['../classHelpSetDialog.html#a59391ca64da7949e23bb6d9ed900e2eb',1,'HelpSetDialog']]],
  ['_7emainwindow',['~MainWindow',['../classMainWindow.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]],
  ['_7eresultdialog',['~ResultDialog',['../classResultDialog.html#a26dcd549337282cf931825ea481fc8c3',1,'ResultDialog']]]
];
