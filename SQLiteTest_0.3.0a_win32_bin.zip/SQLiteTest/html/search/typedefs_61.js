var searchData=
[
  ['anonymvoid',['AnonymVoid',['../mainwindow_8h.html#a1e88eb4912e990e9280b2045fbf8f190',1,'mainwindow.h']]]
];
