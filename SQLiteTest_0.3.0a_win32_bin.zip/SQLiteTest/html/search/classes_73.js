var searchData=
[
  ['sqlite',['SQLite',['../classSQLite.html',1,'']]],
  ['sqlpreferences',['SqlPreferences',['../structSqlPreferences.html',1,'']]]
];
