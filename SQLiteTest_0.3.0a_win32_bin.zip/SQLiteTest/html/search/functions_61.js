var searchData=
[
  ['about',['about',['../classMainWindow.html#a7be6a5d98970ac1a6296c6f9aee1e9bb',1,'MainWindow']]],
  ['aboutdialog',['AboutDialog',['../classAboutDialog.html#ad96fc2ce8de7568ace543b7c69c71c56',1,'AboutDialog']]]
];
