var searchData=
[
  ['open',['open',['../classMainWindow.html#aa7473e4bbbcc281706ac2edef864fb45',1,'MainWindow']]]
];
