var searchData=
[
  ['default_5fdbname',['DEFAULT_DBNAME',['../sqlite_8h.html#acfcad24977a121f8cb40c7abc0861e13',1,'sqlite.h']]],
  ['default_5ftablename',['DEFAULT_TABLENAME',['../sqlite_8h.html#adda28390da72cdfef24377fcd0262e17',1,'sqlite.h']]],
  ['drl_5ftitle',['DRL_TITLE',['../mainwindow_8h.html#a92c41d772914eb2a3066de8b613bd6c0',1,'mainwindow.h']]]
];
