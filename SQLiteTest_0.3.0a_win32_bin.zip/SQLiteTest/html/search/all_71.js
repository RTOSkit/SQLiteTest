var searchData=
[
  ['queryerrormsg',['queryErrorMsg',['../classMainWindow.html#afbc3735a35d28cf9ce9a9873aacc4939',1,'MainWindow']]]
];
