var searchData=
[
  ['resulttimes',['resultTimes',['../classMainWindow.html#a69d381f82b82ca37620172b78d58c4ea',1,'MainWindow']]],
  ['rrlbytes',['RRLbytes',['../classMainWindow.html#ac4e4dd0ba3dd8b958d2aec2271bfe299',1,'MainWindow']]]
];
