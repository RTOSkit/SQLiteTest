var searchData=
[
  ['isqueryerror',['isQueryError',['../classMainWindow.html#a88b9fd4866e9ab0c99f50c7c0801e8de',1,'MainWindow']]]
];
