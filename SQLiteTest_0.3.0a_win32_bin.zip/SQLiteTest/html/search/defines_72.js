var searchData=
[
  ['rrl_5ftitle',['RRL_TITLE',['../mainwindow_8h.html#afdbfb02687a82624eb0775e9398be734',1,'mainwindow.h']]]
];
