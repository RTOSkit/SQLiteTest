var searchData=
[
  ['main',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['main_2ecpp',['main.cpp',['../main_8cpp.html',1,'']]],
  ['mainwindow',['MainWindow',['../classMainWindow.html',1,'MainWindow'],['../classMainWindow.html#a8b244be8b7b7db1b08de2a2acb9409db',1,'MainWindow::MainWindow()']]],
  ['mainwindow_2ecpp',['mainwindow.cpp',['../mainwindow_8cpp.html',1,'']]],
  ['mainwindow_2eh',['mainwindow.h',['../mainwindow_8h.html',1,'']]],
  ['max_5frecords',['MAX_RECORDS',['../mainwindow_8h.html#a475c77257e5782fb60199a7d12a7e53f',1,'mainwindow.h']]],
  ['max_5fsleeps',['MAX_SLEEPS',['../mainwindow_8h.html#ab04ce3533c12d8fcbe009e83411d7cee',1,'mainwindow.h']]],
  ['max_5fturns',['MAX_TURNS',['../mainwindow_8h.html#aff2f9f643149b87035310798f31a5b15',1,'mainwindow.h']]]
];
