var searchData=
[
  ['insertdbrecord',['insertDBRecord',['../classSQLite.html#aa4a76c8a9ec7d8a0101a28c228701e4b',1,'SQLite']]]
];
