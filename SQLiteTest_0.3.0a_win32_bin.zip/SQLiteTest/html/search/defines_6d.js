var searchData=
[
  ['max_5frecords',['MAX_RECORDS',['../mainwindow_8h.html#a475c77257e5782fb60199a7d12a7e53f',1,'mainwindow.h']]],
  ['max_5fsleeps',['MAX_SLEEPS',['../mainwindow_8h.html#ab04ce3533c12d8fcbe009e83411d7cee',1,'mainwindow.h']]],
  ['max_5fturns',['MAX_TURNS',['../mainwindow_8h.html#aff2f9f643149b87035310798f31a5b15',1,'mainwindow.h']]]
];
