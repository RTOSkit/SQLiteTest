var searchData=
[
  ['sqlite',['sqlite',['../classMainWindow.html#acd9e528f003b22f3c17657a89505803a',1,'MainWindow']]],
  ['sqlpreferences',['sqlPreferences',['../classSQLite.html#a2dd6672e754497ad5ad90470e3ef3e33',1,'SQLite']]]
];
