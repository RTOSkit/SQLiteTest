var searchData=
[
  ['text_5ffield_5fsize',['TEXT_FIELD_SIZE',['../mainwindow_8h.html#ad811caf6c72a9a031c67d2af9edc57ab',1,'mainwindow.h']]]
];
