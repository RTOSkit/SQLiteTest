var searchData=
[
  ['resultdialog',['ResultDialog',['../classResultDialog.html',1,'']]]
];
