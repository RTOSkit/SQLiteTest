var searchData=
[
  ['fix_5fnr_5ffields',['FIX_NR_FIELDS',['../mainwindow_8h.html#aa78da16b589b9ca5469c44688b356192',1,'mainwindow.h']]],
  ['fullspeed',['fullSpeed',['../classMainWindow.html#ac3f3016f1a0ad93767c521c2fd349c7b',1,'MainWindow']]]
];
