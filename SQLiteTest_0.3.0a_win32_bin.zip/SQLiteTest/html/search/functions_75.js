var searchData=
[
  ['updatedbrecord',['updateDBRecord',['../classSQLite.html#acd343255f8010fdde87b1d8b2cd65e49',1,'SQLite']]]
];
