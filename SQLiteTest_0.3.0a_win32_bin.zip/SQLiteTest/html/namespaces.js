var namespaces =
[
    [ "sqlitetest", "namespacesqlitetest.html", null ],
    [ "Ui", "namespaceUi.html", null ]
];