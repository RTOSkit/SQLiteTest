var classResultDialog =
[
    [ "ResultDialog", "classResultDialog.html#a3cd48b45618b2b87662ab3d5a53bded7", null ],
    [ "~ResultDialog", "classResultDialog.html#a26dcd549337282cf931825ea481fc8c3", null ]
];