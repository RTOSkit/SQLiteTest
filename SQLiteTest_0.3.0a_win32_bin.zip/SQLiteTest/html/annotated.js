var annotated =
[
    [ "AboutDialog", "classAboutDialog.html", "classAboutDialog" ],
    [ "HelpSetDialog", "classHelpSetDialog.html", "classHelpSetDialog" ],
    [ "MainWindow", "classMainWindow.html", "classMainWindow" ],
    [ "ResultDialog", "classResultDialog.html", "classResultDialog" ],
    [ "SQLite", "classSQLite.html", "classSQLite" ],
    [ "SqlPreferences", "structSqlPreferences.html", "structSqlPreferences" ]
];