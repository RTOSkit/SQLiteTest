var mainwindow_8h =
[
    [ "DRL_TITLE", "mainwindow_8h.html#a92c41d772914eb2a3066de8b613bd6c0", null ],
    [ "FIX_NR_FIELDS", "mainwindow_8h.html#aa78da16b589b9ca5469c44688b356192", null ],
    [ "MAX_RECORDS", "mainwindow_8h.html#a475c77257e5782fb60199a7d12a7e53f", null ],
    [ "MAX_SLEEPS", "mainwindow_8h.html#ab04ce3533c12d8fcbe009e83411d7cee", null ],
    [ "MAX_TURNS", "mainwindow_8h.html#aff2f9f643149b87035310798f31a5b15", null ],
    [ "RRL_TITLE", "mainwindow_8h.html#afdbfb02687a82624eb0775e9398be734", null ],
    [ "TEXT_FIELD_SIZE", "mainwindow_8h.html#ad811caf6c72a9a031c67d2af9edc57ab", null ],
    [ "AnonymVoid", "mainwindow_8h.html#a1e88eb4912e990e9280b2045fbf8f190", null ]
];