var classHelpSetDialog =
[
    [ "HelpSetDialog", "classHelpSetDialog.html#a42eedf3d1994361844e27c2d5455fc85", null ],
    [ "~HelpSetDialog", "classHelpSetDialog.html#a59391ca64da7949e23bb6d9ed900e2eb", null ],
    [ "ClickedBack", "classHelpSetDialog.html#a7183c0405fa07f127a0a9abc6929a8c7", null ],
    [ "ClickedClose", "classHelpSetDialog.html#aa3c79e2757893a38dd2e53271376ddb3", null ],
    [ "ClickedForward", "classHelpSetDialog.html#a2c435b9d4baaaf700d68e2f3433be28d", null ],
    [ "ClickedH0", "classHelpSetDialog.html#ae381f3412a99fec40b901265d0b393c5", null ],
    [ "ClickedH1", "classHelpSetDialog.html#a6c83306c35879d7d46af2b0e1818b0c1", null ],
    [ "ClickedH2", "classHelpSetDialog.html#a21e7bb69468d2d75db0f7c106bdd66fa", null ],
    [ "ClickedH3", "classHelpSetDialog.html#a67325da32306a5330c51639cbb793311", null ],
    [ "ClickedH4", "classHelpSetDialog.html#af2e0e69fc351dce5a0982a1fca5730cf", null ],
    [ "ClickedH5", "classHelpSetDialog.html#a0ef6a793476a27e4a452985d3264bf69", null ],
    [ "ClickedH6", "classHelpSetDialog.html#adadd548eb11c585c0daf8df7d00e09c1", null ],
    [ "ClickedH7", "classHelpSetDialog.html#ab672ac4bea4fd9d86e47dfe4c0359cc8", null ],
    [ "ClickedH8", "classHelpSetDialog.html#aeb83aba8c60d5b6793f2c4f607be1323", null ],
    [ "ClickedHome", "classHelpSetDialog.html#a392d911572314f20320bf43e1c97dacd", null ],
    [ "ClickedRefresh", "classHelpSetDialog.html#a9c38de387e813f10d1783e9327fe4c5a", null ],
    [ "closeEvent", "classHelpSetDialog.html#a2d56d35a2a180de735942cc56d297fd3", null ]
];