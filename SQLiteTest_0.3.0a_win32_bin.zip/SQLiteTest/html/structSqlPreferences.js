var structSqlPreferences =
[
    [ "customCacheSize", "structSqlPreferences.html#a623f8f8b12bdde7ce2c69f6388d3719b", null ],
    [ "customJournalMode", "structSqlPreferences.html#afa1cee8e11c7ca38d32e05c92a6b56da", null ],
    [ "customLockingMode", "structSqlPreferences.html#ad99a3e0cc0c19283aa9337e6a28f0a28", null ],
    [ "customPageSize", "structSqlPreferences.html#aeaa6fa937ead293aa8cd41b86f1c5cf4", null ],
    [ "customSynchronous", "structSqlPreferences.html#a7d309904c4edb9f888d0c8a810def2d1", null ],
    [ "customTempStore", "structSqlPreferences.html#a36b942f872c390f204cc5542fc0662de", null ],
    [ "useAtomicCommit", "structSqlPreferences.html#a36464d4021afe0e0919cce650a1519fe", null ],
    [ "useCustomCacheSize", "structSqlPreferences.html#ad26f9920ddc5ac5f655873d9ecb3ac53", null ],
    [ "useCustomJournalMode", "structSqlPreferences.html#a9aa98cdd591864c7b2382b2d0fff0de9", null ],
    [ "useCustomLockingMode", "structSqlPreferences.html#a22c08a63c97db2f85e08920bf3e22516", null ],
    [ "useCustomPageSize", "structSqlPreferences.html#a7e53d4abaf46acfb84cd8c30fbf3b1df", null ],
    [ "useCustomSynchronous", "structSqlPreferences.html#a3d18d11573e0546e8fe854b7584adab7", null ],
    [ "useCustomTempStore", "structSqlPreferences.html#abcd9f162cf432b71159c7c83adb8ac88", null ],
    [ "useExistDB", "structSqlPreferences.html#ae8bb4bc0c82e4f32c51efdbf3d3e1af5", null ],
    [ "useRamDB", "structSqlPreferences.html#ad7d06ce81f298cf13b7522e48d640a78", null ]
];