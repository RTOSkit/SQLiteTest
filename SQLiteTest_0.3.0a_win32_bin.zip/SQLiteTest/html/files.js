var files =
[
    [ "aboutdialog.cpp", "aboutdialog_8cpp.html", null ],
    [ "aboutdialog.h", "aboutdialog_8h.html", null ],
    [ "helpsetdialog.cpp", "helpsetdialog_8cpp.html", null ],
    [ "helpsetdialog.h", "helpsetdialog_8h.html", null ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ],
    [ "resultdialog.cpp", "resultdialog_8cpp.html", null ],
    [ "resultdialog.h", "resultdialog_8h.html", null ],
    [ "sqlite.cpp", "sqlite_8cpp.html", null ],
    [ "sqlite.h", "sqlite_8h.html", "sqlite_8h" ]
];